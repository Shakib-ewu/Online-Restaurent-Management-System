.module_top, .module_bottom{
  visibility: hidden;
}

table {
  border: 0px !important;
}

.module_content img{
  min-width: 70px;
}

.module_content h2{
  font-size: 30px;
}


